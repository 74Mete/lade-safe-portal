const express = require('express');
const multer = require('multer');
const cors = require('cors');
const path = require('path');
const fs = require('fs');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

const users = {
  admin: { password: 'ladeSafe2024', role: 'admin' },
  SWM: { password: 'SWM123', role: 'customer' },
  SWLB: { password: 'SWLB123', role: 'customer' },
  SWD: { password: 'SWD123', role: 'customer' }
};

app.post('/api/login', (req, res) => {
  const { username, password } = req.body;
  const user = users[username];
  if (user && user.password === password) {
    res.json({ success: true, username, role: user.role });
  } else {
    res.json({ success: false, message: 'Ungültige Zugangsdaten' });
  }
});

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const customer = req.body.customer;
    const dir = path.join(__dirname, 'uploads', customer);
    fs.mkdirSync(dir, { recursive: true });
    cb(null, dir);
  },
  filename: (req, file, cb) => {
    cb(null, file.originalname);
  }
});

const upload = multer({ storage });

app.post('/api/upload', upload.single('file'), (req, res) => {
  res.json({ message: 'Datei erfolgreich hochgeladen!' });
});

app.get('/api/files/:customer', (req, res) => {
  const customer = req.params.customer;
  const dir = path.join(__dirname, 'uploads', customer);
  if (!fs.existsSync(dir)) return res.json([]);
  const files = fs.readdirSync(dir).map(file => ({
    name: file,
    url: `/uploads/${customer}/${file}`
  }));
  res.json(files);
});

app.listen(PORT, () => console.log(`Server läuft auf Port ${PORT}`));
